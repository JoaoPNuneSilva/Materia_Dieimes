def saudacao_personalizada(nome):
    print("Olá, " + nome + "! Bem-vindo(a) à minha função de saudação personalizada.")
saudacao_personalizada("Alice")