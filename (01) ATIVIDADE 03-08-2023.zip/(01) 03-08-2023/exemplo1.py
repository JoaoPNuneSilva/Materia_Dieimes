def saudacao():
    print("Bem-vindo(a) à minha função de saudação!")
saudacao()